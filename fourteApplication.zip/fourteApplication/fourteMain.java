package fourteApplication;

import java.util.Scanner;

public class fourteMain {

	public static void main(String[] args) {
		fourteMain game = new fourteMain();
		game.getInput();
	}

	private void getInput() {
		try(Scanner sc =new Scanner(System.in)){
			System.out.println("Enter total value : ");
			long total = sc.nextInt(); 
			System.out.println("Enter 4 numbers to compute : ");
			int[] array = new int[4];
			for(int i = 0;i<4; i++) {
				array[i] = sc.nextInt();
			}
			boolean check =false;
			for(int i = 0;i<4; i++) {
				check=getValidate(array[i]);
				if(check == false) {
					System.out.println("not having a valid digit");
					break;
				}
			}
			if(check==true) {
				fourteHack hack = new fourteHack();
				hack.doHack(array,total);
			}
		}
	}

	private boolean getValidate(int value) {
		if (value >= 0 && value <= 9)
			return true;
		return false;
	}
}
