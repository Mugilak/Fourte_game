package calculator_Application;

import java.util.Stack;

public class PerformOperation {
	private static int getPrecedence(char op) {
		if (op == '+' || op == '-') {
			return 1;
		} else if (op == '*' || op == '/')
			return 2;
		else if (op == '^') return 3;
		return 0;
	}

	public static double do_Operation(String expression) {
		String regexOperator = "[+-/*//]+";
		String[] numString = expression.split(regexOperator);

		String regexNum = "[0-9]+";
		String[] OpString = expression.split(regexNum);

		Stack<Character> operatorStack = new Stack<>();
		Stack<Double> NumberStack = new Stack<>();

		int i = 1, k = 0, index = 0, peekPrecedence, opPrecedence;

		NumberStack.push(Double.parseDouble(numString[index++]));

		while (i < OpString.length && i > 0) {
			String operator = OpString[i++];
			char op = operator.charAt(0);

			for (int j = k; j < expression.length(); j++) {
				char ch = expression.charAt(j);

				if (op == ch) {
					if (operatorStack.isEmpty()) {
						operatorStack.push(op);
						NumberStack.push(Double.parseDouble(numString[index++]));
						k = j + 1;
					} else {
						peekPrecedence = getPrecedence(operatorStack.peek());
						opPrecedence = getPrecedence(op);
						if (opPrecedence > peekPrecedence) {
							operatorStack.push(op);
							NumberStack.push(Double.parseDouble(numString[index++]));
							k = j + 1;
						} else {
							NumberStack.push(operate(operatorStack.pop(), NumberStack.pop(), NumberStack.pop()));
							i--;
						}
					}
					break;
				}
			}
		}
		while (!operatorStack.isEmpty()) {
			NumberStack.push(operate(operatorStack.pop(), NumberStack.pop(), NumberStack.pop()));
		}
//		System.out.println(expression + " = " + NumberStack.peek());
		return NumberStack.peek();
	}

	private static double operate(char popped, double value1, double value2) {
		if ('+' == popped) {
			return value1 + value2;
		}
		if ('-' == popped) {
			return value2 - value1;
		}
		if ('^' == popped) {
			return Math.pow(value2, value1);
		}
		if ('*' == popped) {
			return value1 * value2;
		}
		if ('/' == popped) {
			if (value1 != 0)
				return value2 / value1;
			else {
				throw new UnsupportedOperationException("Cannot Divide By zero !");
			}
		}
		return 0;
	}

}
