package fourteApplication;

import java.util.LinkedList;
import java.util.Queue;

import calculator_Application.PerformOperation;

public class fourteHack {
	public int ans = 0;

	public void doHack(int[] array, long total) {
		Queue<Integer> queue = new LinkedList<>();
		for (int i = 0; i < 4; i++) {
			queue.offer(array[i]);
		}
		permutation(queue, array);
	}

	public void permutation(Queue<Integer> queue,  int[] array) {
		int polled;
		int i = 0;
		int add;
		loop: while (i < 2) {
			do {
				StringBuilder sb = new StringBuilder();
				for (int j = 0; j < 4; j++) {
					System.out.println(queue);
					polled = queue.poll();
					sb.append(polled);
					sb.append('+');
					
					if (sb.length() == 4) {
						add = (int) PerformOperation.do_Operation(sb.toString());
					}
					queue.offer(polled);
				}
				queue.offer(queue.poll());
				queue.offer(queue.poll());
			} while (array[i] != queue.peek());
			queue.offer(queue.poll());
			i++;
		}
	}
}
